Native development event/synthesis point exports, original bytes and vectors.
Read memory-index.json and manifest.json; validate hashes before loading.
Counts: 3712 events, 91 syntheses. No new model calls.
No raw Qdrant databases, original conversations, QA answers, predictions or API records.
Source bindings are provenance, not a proof of semantic entailment.
Sentence indexes and reviewed dependency rules remain C/E responsibilities.
