D offline contract, 2026-11-23. One diagnostic question conv-48/86 only.
Read summary.json and manifest.json first. Dependencies are provisional legacy rules, not C/E reviewed.
A.inputs.jsonl: contexts with dependency closure; S1.inputs.jsonl: delete synthesis from A without refill.
controls/: B M/N on the same candidate pool. trace.json: D selection and source trace.
Requires PR #77 F 9e7a8e8 and PR #79 B 7126895, plus D code from its PR.
No predictions, labels, paid calls, heldout use, accuracy or coverage result.
Run using docs/phase2-d-packing.md. Do not execute archive contents.
