# S0 30 题真实预测交接给 E

接收人：onlysonder（#31）；生成：hycx233（#19），2026-10-19。

30 道固定题分为前 5 题及剩余 25 题，共 30 次真实回答请求，全部成功，无重试、重复、截断或模拟行。根目录 predictions.jsonl 和 calls.jsonl 按 A 原清单顺序合并；runs/ 保留两个原始批次，不能将根目录与子目录重复计数。

先校验 manifest.json 中各文件 SHA-256，再核对 summary.json 中的 question_set_sha256；以 (method, sample_id, qa_index) 关联 A 的 development.labels.json。标准答案未进入 F 的输入、提示词或本交接包。A 的标签可用固定 PR #38（1d651da）脚本重新生成，output_sha256 见 locomo-smoke.json。

scoring 仍为 0，accuracy 为 null；回答成功不表示答对。本包不提供人工判定或代写 E 的评分结论。费用按实际 usage 和调用时高峰价估算，未核对账户账单。

请返回总体及分类正确数/总数、评分覆盖率、失败计数、原始裁判判定和至少 4 个代表案例核查。保留所有 30 道题的分母。
