# B/D real-text diagnostic contract fixture

One development question conv-48/86 only. NOT a full native-bank retrieval result or performance experiment.
Source: existing s2-predictions-for-E-20261020.zip (SHA256 21a6e76a0f097193cdf5bb746dda76008d4237fae8a5d92028dcce1c51c12de6).
Only question/contexts extracted; predictions and labels excluded. 60 archived top-event texts and original five full syntheses, split into 60 sentences. Vectors freshly encoded from exact rendered texts by pinned local MiniLM revision1110a243fdf4706b3f48f1d95db1a4f5529b4d41; these are NOT the original C native vectors. No truncation, no model downloads or generation API calls.

bundle.jsonl: complete label-free C/B/D interface, with vectors and source IDs.
M/N.inputs.jsonl: public F contexts interface, strict 4096 proxy budget.
trace.json: all scores, selected/rejected candidates, full-selection counts and source mappings.
manifest.json: scope/config/code/input hashes.
summary.json: actual diagnostic results. No answer accuracy.
Re-run commands and dependencies: docs/phase2-b-retrieval.md. A frozen development.inputs.json and F counter asset required separately. Do not infer full 30-question readiness from this restricted fixture.
