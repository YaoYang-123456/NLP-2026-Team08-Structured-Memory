# F phase-two contract fixture

One label-free real development retrieval row, copied unchanged from the frozen
anchor_2048 offline prototype. This is a transport/rendering fixture, not a new
method result or a 4096-budget retrieval selection. No reference answers,
support annotations, predictions, credentials or full caches are included.

Extract into an ignored local directory. From the repository root, run:

    python scripts/run_qa.py --mock --method S2 --variant A --config configs/qa-phase2.json --tokenizer-cache data/tokenizer-cache --input output/f-contract/input.jsonl --out output/f-contract-run
    python scripts/verify_qa_run.py --run output/f-contract-run --tokenizer-cache data/tokenizer-cache

Use a new output path. Compare requests.jsonl hashes and evidence counts against
expected.json; run_id is unique to each invocation and is not part of request_sha256.
Prepare the pinned tiktoken cache separately as documented in docs/qa-integration.md.
