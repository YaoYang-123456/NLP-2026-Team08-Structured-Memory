Native D contract, 2026-11-23. One selected question conv-48/86 from frozen smoke5.
Unlike the earlier diagnostic, event vectors are original native vectors; dense120/lexical120 recall uses the full conversation event bank.
Parent syntheses are still the original five. Dependency rules are provisional, not C/E approved.
Read manifest.json, controls/bundles.jsonl, dependencies.json and trace.json.
candidate-generation-source.json records the source five-question generation; this bundle is its first row.
summary30/summary2048 contain only aggregate offline counters, not answers or coverage scores.
dependency-review.json contains 91 parents, 1144 original sentences and 315 provisional backward edges for C/E review.
Source native archive: phase2-native-memory-20261123.zip; hash and counts are in reports/phase2-native-memory-20261123.json.
Run with docs/phase2-d-packing.md after integrating PR #77/#79/#80. No scripts are contained in this ZIP.
