# S2 → E 评分交接（2026-10-20）

负责人 lanshuheng9-oss；Refs #28、PR #41。

predictions30.jsonl 和 calls30.jsonl 按 A 的固定30题原始顺序合并，联合主键为 (sample_id, qa_index)，不是两个批次各算一次。qa5/qa25 各自 run.json 保存原始批次指纹；不捏造单次30题调用清单。所有30次回答成功、无重试/截断，4次 I don't know 原样保留。每题输入60事件＋5真实综合摘要；标准答案未进入生成输入。

F 配置来源 PR #44 提交14b7b41b561fde1ed5193422ed3084211572e15a，与 PR #41 cb79d2c 候选字节相同，F 已在审核中接受。问答max_tokens512，综合8192，非思考，temperature0/top_p1。

A 的冻结配置来自 PR #38 / 1d651da44cd1bf101ead69794a74f45f91c507a3，配置 SHA256 ec7cfdeca766905be35642d456ff930be843370e7f2abe6dc125491525c3b659；development.inputs.json SHA256 8244dff6123ea8479561bfbe6ad5a36d655b2926d4acbf6fdd0d2ddf356abb63。E 取得同版本 labels 后再关联评分，包内不夹带标准答案。

E 请输出固定分母30及分类8/8/7/7的正确数、评分覆盖率、生成/评分失败，并人工核查至少4例；case-candidates.json 只是来源展示候选，不冒充E已核查或正确答案。当前 accuracy=null，不与S0作准确率排名；S1未跑。

综合真实91次：304025输入＋35834输出＝339859 tokens；回答30次：586282输入＋178输出＝586460 tokens；合计121次成功、926319 tokens。没有核对账户实际账单。最初本地沙箱连接被拒的尝试没有到达服务，不是第122次成功调用；详情在D运行文档。

只包含评分必要输出、配置、汇总和来源样例。没有密钥、标签或Qdrant原库。原始综合调用、完整native导出与检索provenance留D本地output；这个ZIP由用户发给E，生成文件不代表已送达或已评分。
