# 第 8 队：8 分钟 LaTeX 汇报交接包

题目：长对话结构化记忆复现与优化。F（hycx233）负责视频录制，A（ngocnamd93-spec）负责线下汇报；共用本包的幻灯片和逐页讲稿。

- slides-8min.pdf：12 页正文，无备用页；第 3 页系统性提炼，第 8 页共同案例，第 11 页 GitHub、微信群与线下讨论协作说明。
- speaker-script-8min.pdf：7 页逐页讲稿，计划合计 480 秒，约 1,700 个汉字；未进行真人录音计时。
- qa-notes.pdf：3 页独立补充说明与答辩准备，共 15 问。
- main.tex / speaker-script.tex / qa-notes/main.tex：三个可编辑入口。
- speeches.tex：幻灯片备注与讲稿共用的口述正文。
- SOURCES.md：仓库依据与论文页码；SHA256SUMS：包内文件校验。

贡献表展示目前大致贡献，各为 1/6。S1、预算对照和留出评价仍为后续计划。论文框架是基于已有阅读的综合分析，未将六套方法描述为已经完整集成。

## 编译

保留整个目录结构，用 XeLaTeX 编译；需要 TeX Live 的 ctex、Fandol、Beamer、TikZ/PGFplots 等常用组件，无需外部图片。

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=build -jobname=slides-8min main.tex
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=build -jobname=speaker-script-8min speaker-script.tex
latexmk -cd -xelatex -interaction=nonstopmode -halt-on-error -outdir=../build -jobname=qa-notes qa-notes/main.tex
```

## 逐页计划秒数

15、35、60、40、40、30、55、45、45、40、50、25，合计 480 秒。
