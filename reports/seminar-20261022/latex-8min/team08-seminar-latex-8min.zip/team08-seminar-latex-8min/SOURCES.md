# 来源索引

以下路径以仓库为根。交接 ZIP 只包含展示文件与源码，不复制原始数据集、完整模型调用或参考答案包。

| 内容 | 仓库依据 |
| --- | --- |
| 老师要求、8 分钟与分工要求 | `docs/course/seminar-notice-20261020.md` |
| 范围、实验设计、后续方案及分工 | `docs/project-plan.md`，2026-10-21 版本 |
| 方法来源和复现差异 | `notes/six-paper-comparison.md`；`papers/structured-memory-group2/01_StructMem.pdf` 第 2–3 页图 2、第 8 页参数 |
| 六篇论文的系统性提炼 | `reports/homework/sections/07-synthesis.tex`；`notes/six-paper-comparison.md`：StructMem 第 2–3 页图 2；Hindsight 第 2–5 页图 1；Semantic XPath 第 2–5 页图 2；MetaMem 第 3–5 页图 2；HyMEM 第 3–5 页图 1；Text2Mem 第 3–5 页图 2 / 表 1 |
| 协作方式 | `docs/collaboration.md`；本轮用户对微信群沟通与线下讨论的说明 |
| 事件记忆规模 | `reports/structmem-development-complete.json`；`reports/structmem-development-receipt-20261020.json` |
| S0/S2 生成、综合与用量 | `reports/s0-answer-summary-20261019.json`；`reports/structmem-real-run-20261020.json`；`reports/seminar-20261022/answer-audit.json` |
| 最新评分与复算 | `reports/e-score-verification-20261021.json`；`reports/e-score-20261020.md`；`reports/e-judge-audit-handoff-20261021.json` |
| 案例与判改 | `reports/e-case-adjudications-20261020.json`；`reports/seminar-20261022/final-audit.md` 中的原文证据核查（不沿用其中旧审核状态） |
| 综合核查的范围 | `reports/structmem-c-review-d-20261021.json` |
| 回答指令差异 | `configs/qa-s0-20261019.json`；`configs/qa-structmem-20261020.json` |

仓库基线为 `6f6a52f`。本轮未调用回答或裁判 API，未新增实验结果。材料完成不表示已经真人排练、录制、上传或确认课程提交格式。
